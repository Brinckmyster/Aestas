# Email Template for Karen (Brinckmyster@gmail.com)

**Subject:** BrainBridge Access - Full Permissions Granted for Mary's Academic Support

---

Hi Karen,

You've been granted **full access** to my BrainBridge academic support system at BYU-Idaho. This system helps manage my brain injury accommodations and academic success automatically.

## Your Access Details:
- **Login Email:** Brinckmyster@gmail.com  
- **Role:** Full Access (coding permissions enabled)
- **Dashboard:** [BrainBridge Web App Link]
- **Perplexity AI Integration:** Enabled for code editing

## Your Permissions Include:
✅ **Edit protocols and triggers** - Modify when "bad brain day" alerts activate  
✅ **Access built-in Perplexity coding interface** - Make changes to the app using AI  
✅ **Modify family access levels** - Add/remove other family or healthcare providers  
✅ **View all health/academic logs** - See real-time cognitive status and patterns  
✅ **Remote support from Colorado** - Help me manage academic challenges from afar  

## My Health Conditions (For Context):
- **Brain injury** (venous sinus stenosis) - affects processing speed and memory
- **Dyslexia** - reading and comprehension challenges  
- **Gastroparesis** - digestive issues affecting energy and focus
- **Fibromyalgia & chronic pain** - impacts concentration and attendance
- **Metal allergies** - can't use traditional wearable monitors

## How BrainBridge Helps:
1. **Auto-detects "bad brain days"** using typing patterns and camera-based heart rate monitoring
2. **Automatically emails professors** when I need accommodations activated
3. **Reschedules exams** through BYU-Idaho's Testing Center
4. **Alerts you in Colorado** when I'm struggling and need support
5. **Tracks patterns** for healthcare providers and disability services

## What I Need From You:
- **Monitor my dashboard** for red/yellow alerts indicating cognitive strain
- **Help modify protocols** when my needs change
- **Approve emergency activations** when I'm too foggy to recognize I need help
- **Coordinate with Mom** for additional family support

## Emergency Protocols:
When the system detects a "bad brain day":
- Professors get automatic accommodation emails
- Non-urgent tasks get rescheduled  
- You get SMS alerts to check in
- Audio-only learning mode activates (less visual strain)

## BYU-Idaho Integration:
- **I-Plan calendar sync** - tracks assignments and deadlines
- **Testing Center integration** - automatic exam rescheduling
- **Accessibility Services logs** - shares data for accommodation updates
- **Kurzweil 3000 activation** - text-to-speech for readings

## Privacy & Security:
- **FERPA compliant** - academic data stays protected
- **HIPAA encrypted** - health information secured
- **BYU-Idaho SSO** - uses official student login system
- **Audit logs** - tracks all changes you make

## Getting Started:
1. Click the BrainBridge link in this email
2. Login with Brinckmyster@gmail.com
3. Complete 2FA setup (text + email verification)
4. Explore the family dashboard and coding interface

## Questions or Issues:
- **Reply to this email** for questions about the system
- **Call BYU-Idaho Accessibility:** (208) 496-9210 (mention BrainBridge)
- **Emergency contact:** If you can't reach me and see red alerts

This system is designed to work automatically, but having you as backup support from Colorado gives me confidence that I won't fall through the cracks like I did in 2012-2015 before my brain injury was diagnosed.

Thank you for being willing to help me succeed at BYU-Idaho!

Love,
Mary

---

**P.S.** The system learns from patterns, so the more data it collects, the better it gets at predicting when I need help. Your oversight ensures it's working properly and making good decisions.