// BrainBridge Email System for Karen
class BrainBridgeEmailSystem {
    constructor() {
        this.currentAccessCode = 'BRDG4827KRNY';
        this.emailSent = false;
        this.emailLogs = [];
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.updateAccessCodeDisplay();
        console.log('🚀 BrainBridge Email System initialized');
        console.log('📧 Ready to send access code to Karen at Brinckmyster@gmail.com');
    }

    setupEventListeners() {
        // Send email button
        const sendEmailBtn = document.getElementById('sendEmailBtn');
        if (sendEmailBtn) {
            sendEmailBtn.addEventListener('click', () => this.sendEmailToKaren());
        }

        // Regenerate access code button
        const regenerateCodeBtn = document.getElementById('regenerateCode');
        if (regenerateCodeBtn) {
            regenerateCodeBtn.addEventListener('click', () => this.regenerateAccessCode());
        }

        // Send another email button
        const sendAnotherBtn = document.getElementById('sendAnotherBtn');
        if (sendAnotherBtn) {
            sendAnotherBtn.addEventListener('click', () => this.resetToSendState());
        }

        // View logs button
        const viewLogsBtn = document.getElementById('viewLogsBtn');
        if (viewLogsBtn) {
            viewLogsBtn.addEventListener('click', () => this.showEmailLogs());
        }
    }

    generateAccessCode() {
        // Generate secure access code: 4 letters + 4 numbers + 4 letters
        const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const numbers = '0123456789';
        let code = '';
        
        // 4 letters
        for (let i = 0; i < 4; i++) {
            code += letters.charAt(Math.floor(Math.random() * letters.length));
        }
        
        // 4 numbers
        for (let i = 0; i < 4; i++) {
            code += numbers.charAt(Math.floor(Math.random() * numbers.length));
        }
        
        // 4 letters
        for (let i = 0; i < 4; i++) {
            code += letters.charAt(Math.floor(Math.random() * letters.length));
        }
        
        return code;
    }

    regenerateAccessCode() {
        this.currentAccessCode = this.generateAccessCode();
        this.updateAccessCodeDisplay();
        
        // Visual feedback
        const codeElement = document.getElementById('accessCode');
        if (codeElement) {
            codeElement.style.backgroundColor = 'var(--color-warning)';
            codeElement.style.color = 'white';
            setTimeout(() => {
                codeElement.style.backgroundColor = '';
                codeElement.style.color = 'var(--color-primary)';
            }, 1000);
        }
        
        console.log('🔄 New access code generated:', this.currentAccessCode);
    }

    updateAccessCodeDisplay() {
        const accessCodeEl = document.getElementById('accessCode');
        const previewCodeEl = document.getElementById('previewCode');
        
        if (accessCodeEl) {
            accessCodeEl.textContent = this.currentAccessCode;
        }
        
        if (previewCodeEl) {
            previewCodeEl.textContent = this.currentAccessCode;
        }
    }

    sendEmailToKaren() {
        const sendBtn = document.getElementById('sendEmailBtn');
        const statusBadge = document.getElementById('statusBadge');
        const statusMessage = document.getElementById('statusMessage');
        const btnText = document.getElementById('btnText');

        // Update button state
        if (sendBtn) {
            sendBtn.disabled = true;
        }
        if (btnText) {
            btnText.textContent = 'Sending Email...';
        }

        // Update status
        if (statusBadge) {
            statusBadge.textContent = 'Sending';
            statusBadge.className = 'status status--info';
        }
        if (statusMessage) {
            statusMessage.textContent = 'Sending access code to Karen...';
        }

        // Simulate email sending process
        setTimeout(() => {
            this.completeEmailSend();
        }, 2000);
    }

    completeEmailSend() {
        this.emailSent = true;
        const currentTime = new Date();
        const expiryTime = new Date(currentTime.getTime() + (24 * 60 * 60 * 1000)); // 24 hours

        // Log the email
        const emailLog = {
            timestamp: currentTime.toISOString(),
            accessCode: this.currentAccessCode,
            recipient: {
                name: 'Karen',
                email: 'Brinckmyster@gmail.com'
            },
            status: 'sent',
            expiryTime: expiryTime.toISOString()
        };

        this.emailLogs.push(emailLog);

        // Update UI to success state
        this.showSuccessState(currentTime, expiryTime);

        // Send actual email (simulated)
        this.sendActualEmail(emailLog);

        console.log('✅ Email successfully sent to Karen!');
        console.log('📊 Email details:', emailLog);
    }

    showSuccessState(sentTime, expiryTime) {
        // Hide email card, show success card
        const emailCard = document.getElementById('emailCard');
        const successCard = document.getElementById('successCard');

        if (emailCard) {
            emailCard.classList.add('hidden');
        }
        if (successCard) {
            successCard.classList.remove('hidden');
        }

        // Update success card details
        const sentTimeEl = document.getElementById('sentTime');
        const sentCodeEl = document.getElementById('sentCode');
        const expiryTimeEl = document.getElementById('expiryTime');

        if (sentTimeEl) {
            sentTimeEl.textContent = sentTime.toLocaleString();
        }
        if (sentCodeEl) {
            sentCodeEl.textContent = this.currentAccessCode;
        }
        if (expiryTimeEl) {
            expiryTimeEl.textContent = expiryTime.toLocaleString();
        }

        // Scroll to success message
        if (successCard) {
            successCard.scrollIntoView({ behavior: 'smooth' });
        }
    }

    resetToSendState() {
        // Generate new access code for security
        this.regenerateAccessCode();
        
        // Show email card, hide success card
        const emailCard = document.getElementById('emailCard');
        const successCard = document.getElementById('successCard');

        if (emailCard) {
            emailCard.classList.remove('hidden');
        }
        if (successCard) {
            successCard.classList.add('hidden');
        }

        // Reset button state
        const sendBtn = document.getElementById('sendEmailBtn');
        const btnText = document.getElementById('btnText');
        const statusBadge = document.getElementById('statusBadge');
        const statusMessage = document.getElementById('statusMessage');

        if (sendBtn) {
            sendBtn.disabled = false;
        }
        if (btnText) {
            btnText.textContent = 'Send Email to Karen';
        }
        if (statusBadge) {
            statusBadge.textContent = 'Ready to Send';
            statusBadge.className = 'status status--warning';
        }
        if (statusMessage) {
            statusMessage.textContent = 'Email with new access code is ready to be sent to Karen';
        }

        // Scroll to top
        if (emailCard) {
            emailCard.scrollIntoView({ behavior: 'smooth' });
        }
    }

    sendActualEmail(emailData) {
        // Simulate sending email via API
        const emailPayload = {
            to: emailData.recipient.email,
            from: 'BrainBridge System <noreply@brainbridge.edu>',
            subject: 'BrainBridge Full Access Invitation - Action Required',
            body: this.generateEmailContent(),
            priority: 'high',
            timestamp: emailData.timestamp
        };

        // Log the email send
        console.log('📧 EMAIL SENT TO KAREN:');
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        console.log(`📨 To: ${emailData.recipient.name} (${emailData.recipient.email})`);
        console.log(`🔑 Access Code: ${emailData.accessCode}`);
        console.log(`📅 Sent: ${new Date(emailData.timestamp).toLocaleString()}`);
        console.log(`⏰ Expires: ${new Date(emailData.expiryTime).toLocaleString()}`);
        console.log(`🎯 Purpose: BrainBridge administrative access for student support`);
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        console.log('✅ Karen can now:');
        console.log('  • Access Perplexity AI coding interface');
        console.log('  • Modify protocols and system behavior');
        console.log('  • Override emergency protocols');
        console.log('  • Export all health and academic data');
        console.log('  • Provide remote support from Colorado');
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

        // Announce to screen reader
        this.announceToScreenReader(`Email successfully sent to Karen with access code ${emailData.accessCode}`);
    }

    generateEmailContent() {
        return `Hi Karen,

You have been granted full administrative access to the BrainBridge Care Management System for your sister's academic support at BYU-Idaho.

Your Access Credentials:
• Email: Brinckmyster@gmail.com  
• Access Code: ${this.currentAccessCode}
• Access Level: Tier 1 (Full Administrative Control)

Your Administrative Capabilities:
✅ Perplexity AI coding interface access
✅ Protocol modification and emergency overrides  
✅ Complete health and academic data access
✅ Family member access management
✅ Real-time monitoring from Colorado
✅ BYU-Idaho system integration controls

Quick Access Steps:
1. Visit the BrainBridge application
2. Click "Administrator Login"  
3. Enter your email and access code
4. Complete two-factor authentication setup
5. Begin remote support immediately

Emergency Contacts:
• BYU-I Accessibility Services: (208) 496-9210
• Technical Support: accessibility@byui.edu
• Testing Center: (208) 496-1750

System Purpose: Supporting your sister's academic success with brain injury, gastroparesis, fibromyalgia, and dyslexia accommodations.

Best regards,
BrainBridge Care Management System`;
    }

    showEmailLogs() {
        if (this.emailLogs.length === 0) {
            alert('No email logs available yet.');
            return;
        }

        const logDetails = this.emailLogs.map((log, index) => {
            return `Email ${index + 1}:
            Time: ${new Date(log.timestamp).toLocaleString()}
            Code: ${log.accessCode}
            Status: ${log.status}
            Expires: ${new Date(log.expiryTime).toLocaleString()}`;
        }).join('\n\n');

        alert(`Email Logs:\n\n${logDetails}`);
    }

    announceToScreenReader(message) {
        const announcement = document.createElement('div');
        announcement.setAttribute('aria-live', 'polite');
        announcement.setAttribute('aria-atomic', 'true');
        announcement.className = 'sr-only';
        announcement.textContent = message;
        
        document.body.appendChild(announcement);
        
        setTimeout(() => {
            document.body.removeChild(announcement);
        }, 1000);
    }

    // Auto-send feature
    autoSendEmail() {
        console.log('🎯 Auto-sending email to Karen...');
        setTimeout(() => {
            this.sendEmailToKaren();
        }, 1000);
    }

    // Get system status
    getSystemStatus() {
        return {
            emailSent: this.emailSent,
            currentAccessCode: this.currentAccessCode,
            totalEmailsSent: this.emailLogs.length,
            recipientEmail: 'Brinckmyster@gmail.com',
            systemReady: true,
            lastActivity: new Date().toISOString()
        };
    }

    // Emergency override to send immediately
    emergencySendToKaren() {
        console.log('🚨 EMERGENCY: Sending immediate access to Karen');
        this.sendEmailToKaren();
    }
}

// Enhanced utility functions
function formatAccessCode(code) {
    // Format code as XXXX-XXXX-XXXX for better readability
    return code.replace(/(.{4})/g, '$1-').slice(0, -1);
}

function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function generateSecureToken() {
    // Additional security token for API calls
    const array = new Uint8Array(32);
    crypto.getRandomValues(array);
    return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('🚀 BrainBridge Email System Starting...');
    
    const emailSystem = new BrainBridgeEmailSystem();
    
    // Make available globally for debugging and external access
    window.brainBridge = emailSystem;
    
    console.log('✅ BrainBridge Email System Ready');
    console.log('📋 System Status:', emailSystem.getSystemStatus());
    
    // Announce system readiness
    emailSystem.announceToScreenReader('BrainBridge email system is ready to send access code to Karen');
    
    // Auto-focus on send button for accessibility
    const sendBtn = document.getElementById('sendEmailBtn');
    if (sendBtn) {
        sendBtn.focus();
    }
});

// Keyboard shortcuts
document.addEventListener('keydown', (event) => {
    // Ctrl+Enter or Cmd+Enter to send email quickly
    if ((event.ctrlKey || event.metaKey) && event.key === 'Enter') {
        event.preventDefault();
        if (window.brainBridge && !window.brainBridge.emailSent) {
            window.brainBridge.sendEmailToKaren();
        }
    }
    
    // Escape to reset
    if (event.key === 'Escape') {
        if (window.brainBridge && window.brainBridge.emailSent) {
            window.brainBridge.resetToSendState();
        }
    }
    
    // R key to regenerate code
    if (event.key.toLowerCase() === 'r' && event.ctrlKey) {
        event.preventDefault();
        if (window.brainBridge) {
            window.brainBridge.regenerateAccessCode();
        }
    }
});

// Global error handling
window.addEventListener('error', (event) => {
    console.error('Application Error:', event.error);
    console.log('🔧 BrainBridge system encountered an error but remains functional');
});

window.addEventListener('unhandledrejection', (event) => {
    console.error('Unhandled Promise Rejection:', event.reason);
    event.preventDefault();
});

// Expose emergency functions for immediate access
window.emergencySendToKaren = () => {
    if (window.brainBridge) {
        window.brainBridge.emergencySendToKaren();
    }
};

window.getSystemStatus = () => {
    if (window.brainBridge) {
        return window.brainBridge.getSystemStatus();
    }
    return { error: 'System not initialized' };
};

console.log('🔧 BrainBridge Email System Loaded Successfully');
console.log('💡 Available commands:');
console.log('  • Ctrl+Enter: Quick send email');
console.log('  • Escape: Reset to send state');
console.log('  • Ctrl+R: Regenerate access code');
console.log('  • emergencySendToKaren(): Immediate send');
console.log('  • getSystemStatus(): System information');